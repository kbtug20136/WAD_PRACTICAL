# Very Simple Portfolio (literally very simple)

### A very simple portfolio page made with HTML, CSS & JS.

- First of all, this is my first open source project. So please show me some respect and star my project. 🤠
- Used isotope, typed, owlcarousel and more stuffs.
- Responsive & mobile-friendly. (I think so 🤠)
- And yes, It's not very pleasing to eyes, I know.
- Take a look: https://subuthai.github.io/VerySimplePortfolio/

### Contact me:

[<img align="left" alt="subuthai.xyz" width="22px" src="https://img.icons8.com/fluency/48/000000/globe.png" />][website]
[<img align="left" alt="subuthai | YouTube" width="22px" src="https://img.icons8.com/fluency/48/000000/youtube-play.png" />][youtube]
[<img align="left" alt="subuthai_ | Twitter" width="22px" src="https://img.icons8.com/fluency/48/000000/twitter.png" />][twitter]
[<img align="left" alt="subuthai_ | Instagram" width="22px" src="https://img.icons8.com/fluency/48/000000/instagram-new.png" />][instagram]
[<img align="left" alt="subuthai_ | Discord" width="22px" src="https://img.icons8.com/fluency/48/000000/discord.png" />][discord]

[website]: https://subuthai.xyz
[twitter]: https://twitter.com/subuthai_
[youtube]: https://youtube.com/Subuthai
[instagram]: https://instagram.com/subuthai_
[discord]: https://discord.gg/yBPcHQcVjB
